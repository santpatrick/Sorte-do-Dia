package br.com.up.androidproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button buttonSortear;
    private TextView textResultado;
    private ArrayList<String> listaFrases = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaFrases.add("Hoje Vai fazer sol.");
        listaFrases.add("Não vai chover hoje.");
        listaFrases.add("Seus amigos nao vao te criticar hoje.");
        listaFrases.add("A aula hoje vai ser top.");
        
        buttonSortear = findViewById(R.id.btnSortear);
        textResultado = findViewById(R.id.txtResultado);




        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int position = new Random().nextInt(listaFrases.size());
                String text = listaFrases.get(position);
                textResultado.setText(text);

            }
        };

        buttonSortear.setOnClickListener(clickListener);



    }
}